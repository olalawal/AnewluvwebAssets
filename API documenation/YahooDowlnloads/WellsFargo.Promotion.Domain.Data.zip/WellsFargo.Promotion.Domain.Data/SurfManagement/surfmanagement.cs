﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace WellsFargo.Promotion.Domain.Data.SurfManagement
{
    [DataContract(Namespace = "SurfManagement")]
    public class surfmanagement
    {
        [DataMember]
        public int id { get; set; }
  


      
        [DataMember]
        public string requesttype { get; set; }
        [DataMember]
        public string category { get; set; }
        [DataMember]
        public string subcategory { get; set; }
        [DataMember]
        public string status { get; set; }
        [DataMember]
        public string summary { get; set; } 
        [DataMember]
        public DateTime opendate { get; set; } 
    }
}
