﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace WellsFargo.Promotion.Domain.Data.SurfManagement.ViewModels
{
    [DataContract]
    public class surfviewmodel
    {
        [DataMember]
        public string id { get; set; }

        [DataMember]
        public string requesttype { get; set; }
        [DataMember]
        public string subcategory { get; set; }
        [DataMember]
        public string status { get; set; }
        [DataMember]
        public string summary { get; set; }
        [DataMember]
        public DateTime opendate { get; set; } 
    }
}
