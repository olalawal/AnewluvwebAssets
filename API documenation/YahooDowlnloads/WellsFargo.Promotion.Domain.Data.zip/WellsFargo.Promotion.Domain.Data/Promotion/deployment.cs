﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace WellsFargo.Promotion.Domain.Data
{
     [DataContract(Namespace = "")]
    public class deployment
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int order { get; set; }
        [DataMember]
        public string deploymentlocation { get; set; }  //maybe this is a part of the  promotion object
        [DataMember]
        public DateTime? deploydate { get; set; }

        [DataMember]
        public int deploymenttype_id { get; set; }  //how is review type different from review category
        [DataMember]
        public virtual lu_deploymenttype deploymenttype { get; set; }  //how is review type different from review category
        [DataMember]
        public int enviroment_id { get; set; }  //how is review type different from review category
        [DataMember]
        public virtual lu_enviroment enviroment { get; set; }
        [DataMember]
        public int promotionobject_id { get; set; }  //how is review type different from review category
        [DataMember]
        public virtual promotionobjectdetail promotionobjectdetail { get; set; }
        [DataMember]
        public int? status_id { get; set; }  //how is review type different from review category
        [DataMember]
        public virtual lu_status  status { get; set; }  //only works if pass fail na are exclusive
        [DataMember]
        public DateTime? statusdate { get; set; }
        //connection to history object 
        public virtual ICollection<deploymenthistory> history { get; set; }
       
    }
}
