﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace WellsFargo.Promotion.Domain.Data
{
    [DataContract(Namespace = "")]
    public class reviewdetail
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int? passcount { get; set; }
        [DataMember]
        public int? failcount { get; set; }
        [DataMember]
        public bool? nacount { get; set; }
        [DataMember]
        public string notes { get; set; }
        //moved from review level
        [DataMember]
        public bool exceptiongranted { get; set; }
        [DataMember]
        public string exceptiongrantor { get; set; }
        [DataMember]
        public string exceptionnotes { get; set; }
        [DataMember]
        public DateTime? exceptiondate { get; set; }
        [DataMember]
        public DateTime? startdate { get; set; }  //bascially same as submit date
        [DataMember]
        public DateTime? completedate { get; set; } //rename of reviewdate can roll back
        //no need for FK since they used shared FK
         [DataMember]
        public virtual review review { get; set; }
      
    }
}
