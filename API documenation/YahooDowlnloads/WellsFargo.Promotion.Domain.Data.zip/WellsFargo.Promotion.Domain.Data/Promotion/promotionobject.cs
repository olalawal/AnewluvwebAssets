﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace WellsFargo.Promotion.Domain.Data
{
    [DataContract(Namespace = "http://WellsFargo.com/WellsFargo.Services.Promotion")]
    public  class promotionobject
    {
       [DataMember]
        public int id { get; set; }
        [DataMember]
        public string surfstring { get; set; }
        //4-22-2013 added surf info
        [DataMember]
        public virtual int surf_id { get; set; }
       [DataMember]
        public virtual surf surf { get; set; }
        [DataMember]
        public int? order { get; set; }
        //[DataMember]
       // public bool? initialpromotionobject { get; set; }  
        //related to deployment 
      
         [DataMember]
        public virtual promotionobjectdetail detail { get; set; }
        //public virtual reviewhistory reviewhistory { get; set; }

        //Important make optional stuff nullable
         [DataMember]
         public int? promoter_id { get; set; }
         [DataMember] 
         public virtual lu_promoter promoter { get; set; }

        //forlink back to history
         [IgnoreDataMember]
        public virtual ICollection<promotionobjecthistory> history { get; set; }
        [DataMember]
        public int objecttype_id { get; set; }
       [DataMember]
       public virtual lu_promotionobjecttype objecttype { get; set; }
       //public int promotionobjectstatus_id { get; set; }
         [DataMember]
         public virtual int? status_id { get; set; }
         [DataMember]
        public virtual lu_status status { get; set; }
        [DataMember]
        public DateTime? statusdate { get; set; } // this could be problematic i.e since its tied to a lookup    
       
       

    }
}
