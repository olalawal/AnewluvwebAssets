﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace WellsFargo.Promotion.Domain.Data
{
    [DataContract(Namespace = "")]
    public  class promotionobjectdetail
    {
        [DataMember]
        public int id { get; set; }  //pk and fk actually
        
        //[DataMember]
       // public int promotionobject_id { get; set; }
      
        public virtual  promotionobject  promotionobject { get; set; }
        //movied from promotion object level
        [DataMember]
        public string developer { get; set; }
        [DataMember]
        public string reviewer { get; set; }  //rename of reviewed by for conistency       
        [DataMember]
        public bool? reviewitemsadded { get; set; }
        [DataMember]
        public string objectdetail { get; set; }
        [DataMember]
        public string physicalpath{ get; set; }
        [DataMember]
        public string reportdeploypath { get; set; }


        [DataMember]
        public DateTime? submittdate { get; set; }

         [DataMember]
        public virtual ICollection<deployment> deployments { get; set; }
         [DataMember]
        public virtual ICollection<review> reviews { get; set; }

     

    }
}
