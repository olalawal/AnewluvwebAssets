﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace  WellsFargo.Promotion.Domain.Data
{
    [DataContract(Namespace = "")]
    public class deploymenthistory
    {
        [DataMember]
        public Guid id { get; set; }
        [DataMember]
        public int order { get; set; }
        [DataMember]
        public string deploymentlocation { get; set; }

        [DataMember]
        public int? status_id { get; set; }  //how is review type different from review category
        [DataMember]
        public lu_status status { get; set; }
        [DataMember]
        public DateTime? statusdate { get; set; }
        [DataMember]
        public DateTime? deploydate { get; set; }
        [DataMember]
        public string userlogin { get; set; }
        //ties this record to the original changed item
        // public int deploymentid { get; set; }

        [DataMember]
        public int deployment_id { get; set; }  //how is review type different from review category
        // [DataMember]
        public virtual deployment deployment { get; set; }
        [DataMember]
        public bool? initialdeployment { get; set; }
        [DataMember]
        public DateTime timestamp { get; set; }
    }
}
