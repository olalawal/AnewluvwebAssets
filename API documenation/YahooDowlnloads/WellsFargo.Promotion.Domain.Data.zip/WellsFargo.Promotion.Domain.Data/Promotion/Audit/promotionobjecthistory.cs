﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace WellsFargo.Promotion.Domain.Data
{
    [DataContract(Namespace = "")]
    public class promotionobjecthistory
    {
        [DataMember]
        public Guid id { get; set; }
        [DataMember]
        public int order { get; set; }
        [DataMember]
        public string developer { get; set; }
        [DataMember]
        public string reviewer { get; set; }  //rename of reviewed by for conistency
        //public int? passcount { get; set; }
        //public int? failcount { get; set; }
        [DataMember]
        public bool? reviewitemsadded { get; set; }
        [DataMember]
        public string objectdetail { get; set; }
        [DataMember]
        public string reportdeploypath { get; set; }
        [DataMember]
        public DateTime? submittdate { get; set; }
        [DataMember]
        public DateTime? reviewcompletedate { get; set; } //rename of reviewdate can roll back      

        [DataMember]
        public DateTime? statusupdatedate { get; set; } // this could be problematic i.e since its tied to a lookup


        [DataMember]
        public int? status_id { get; set; }
        [DataMember]
        public virtual lu_status status { get; set; }
        [DataMember]
        public int promotionobjecttype_id { get; set; }
        [DataMember]
        public virtual lu_promotionobjecttype promotionobjecttype { get; set; }
        [DataMember]
        public int? promoter_id { get; set; }
        [DataMember]
        public virtual lu_promoter promoter { get; set; }
        //ties this record to the original changed item
        [DataMember]
        public int promotionobject_id { get; set; }
        [DataMember]
        public promotionobject promotionobject { get; set; }
        //added flag per travis request for initial review
        [DataMember]
        public bool? initialpromotionobject { get; set; }
     
        [DataMember]
        public DateTime timestamp { get; set; }
       

    }
}
