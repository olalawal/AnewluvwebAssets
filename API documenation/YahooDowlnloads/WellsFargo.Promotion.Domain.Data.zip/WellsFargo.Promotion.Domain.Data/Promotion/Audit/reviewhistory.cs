﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace WellsFargo.Promotion.Domain.Data
{
    [DataContract(Namespace = "")]
    public class reviewhistory
    {
        [DataMember]
        public Guid id { get; set; }
        [DataMember]
        public string notes { get; set; }
        
        //public DateTime? adddate { get; set; }  //this info is gleaned from history tables
        [DataMember]
        public int reviewtype_id { get; set; }
        [DataMember]
        public virtual lu_reviewtype reviewtype { get; set; }  //how is review type different from review category
        [DataMember]
        public int reviewcategory_id { get; set; }
        [DataMember]
        public virtual lu_reviewcategory reviewcategory { get; set; }
        //public virtual ICollection<promotionobject> promotionobjects { get; set; }

        [DataMember]
        public int? status_id { get; set; }
        public virtual lu_status  status { get; set; }  //only works if pass fail na are exclusive
        [DataMember]
        public DateTime? statusdate { get; set; }
        
        [DataMember]
        public int review_id { get; set; }
        //ties this record to the original changed item      
        public virtual  review  review { get; set; }
        //added flag per travis request for initial review
        [DataMember]
        public bool? initialreview { get; set; }

        //moved back to from review level
        [DataMember]
        public bool exceptiongranted { get; set; }
        [DataMember]
        public string exceptiongrantor { get; set; }
        [DataMember]
        public string exceptionnotes { get; set; }
        [DataMember]
        public DateTime? exceptiondate { get; set; }

        [DataMember]
        public DateTime timestamp { get; set; }

    }
}
