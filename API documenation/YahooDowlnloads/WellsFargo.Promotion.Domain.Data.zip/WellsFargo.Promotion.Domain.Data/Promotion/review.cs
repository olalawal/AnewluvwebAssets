﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace WellsFargo.Promotion.Domain.Data
{
    [DataContract(Namespace = "")]
    public class review
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int order { get; set; } 
        //public DateTime? adddate { get; set; }  //this info is gleaned from history tables and reviewdetail startdate
        public int reviewtype_id { get; set; }
        public virtual lu_reviewtype reviewtype { get; set; }  //how is review type different from review category
        //public virtual lu_reviewcategory reviewcategory { get; set; }
        //public virtual ICollection <promotionobject> promotionobjects { get; set; }
        //4-26-2013 olawal flipped this relation ship around 1 promotion object can have many reviews
        //not the other way around.

        [DataMember]
        public virtual int promotionobject_id { get; set; }
          [DataMember]
        public virtual promotionobjectdetail promotionobjectdetail { get; set; }
          [DataMember]
        public virtual reviewdetail detail { get; set; }  //not a collection   
        //forlink back to history
         [IgnoreDataMember]
        public virtual ICollection<reviewhistory> history { get; set; }

         [DataMember]
         public int? status_id { get; set; }  
        [DataMember]
        public virtual lu_status status { get; set; }  //only works if pass fail na are exclusive
        [DataMember]
        public DateTime? statusdate { get; set; }  
    }
}
