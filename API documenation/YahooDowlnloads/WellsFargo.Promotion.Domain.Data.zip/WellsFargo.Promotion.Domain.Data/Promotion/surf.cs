﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace WellsFargo.Promotion.Domain.Data
{
    [DataContract(Namespace = "")]
    public class surf
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public string surfid { get; set; }
        [DataMember]
        public string releasenotes { get; set; }
        [IgnoreDataMember]
        public virtual ICollection<promotionobject> promotionobjects { get; set; }  //how is review type different from review category
        [DataMember]
        public DateTime? completedate { get; set; }  
    }
}
