﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace WellsFargo.Promotion.Domain.Data
{
    public enum  reviewtypeenum
    {
    [Description("Select a rule ")]
     notset ,
    [Description("Create SSIS designed for new package must be approved by Travis Hoff or Jason Marshall.  ")]  
    packagevalidatecreatessisapproval ,
    [Description("Validate standard naming convention with no underscores, spaces or special characters.    i.e. -  (jobMERSDailyReport.dtsx)")]
    packagevalidatenameconvention ,
    [Description("Validate that description field in the package Properties should contain an explanation of the package.  ")]
    packagevalidatedescriptionfeild ,
    [Description("Validate that package-level encryption is not used.  If storing sensitive data, use configuration file instead.")]
    packagevalidatenopackagelevelencryption,
    [Description("Use Annotation in packages to describe the use of Task/Component Functions.  Documenting the information would  be helpful to someone supporting the  process. ")]
    packageuseannotationinpackages ,
    [Description("Validate that within the Visual Studio package properties. ENABLE Package Configuration should be checked. ")]
    packagevalidaetvisualstudiopackageenableconfigchecked ,
    [Description(" On 'Select Configuration Type' page, select the 'Configuration location is stored in an environment variable' option and make sure the SSISReportConfig value is selected. ")]
    packagevalidateconfigurationtypechecked ,
    [Description("Validate Table Naming Convention.  Table name with no underscores, spaces or special characters.    i.e.- (FinaldocsRPT.dbo.BondRiskMatrix) ")]
    packagevalidatetablenamingconvention ,
    [Description("All columns that represent the same data across tables should have the same name and data types ")]
    packagevalidateallcoulmndatadatatypes ,
    [Description("Column names with no underscores, no spaces or special characters.    i.e.- ([LoanNbr/ DescID) ")]
    packagevalidateallcoulmnnames ,
    [Description("Best practice before creating new table in dev.  Communicate with the DBA for approval on new table, the use of primary key and if table needs to have Clustered/NonClustered Index or Unique Index. ")]
    packagevalidatetablebestpractice ,
    [Description("Variable named “Rerun” with instructions to rerun package must be present ")]
    packagevalidatererunvariableexists ,
    [Description("Descriptive names must be used for all tasks/components (Data Conversion can be left as-is) ")]
    packagevalidatedescriptivenamesfortasks ,
    [Description("Some variables must conform to naming convention outlined in DMG on SharePoint; see DMG for details (ex. InputFile name - InputFileRmExtract = rms_extract.txt) ")]
    packagevalidatevariablenamingconv ,
    [Description("Validate naming convention for Shared Datasets, should be specific to business criteria. i.e.- (LenderRelationMonthlyRpt) ")]
    reportvalidateshareddatasetnameconv,
    [Description("Validate the use of Shared datasets and must be used stored procedures to return data. Must conform to the T-SQL Best Practices ")]
    reportvalidateuseofshareddatasetsandsprocstoreturndata,
    [Description("Report header should be the variable [&ReportName] for any 'front facing' reports, not drill-through.  Report Title:  14pt, Section title(s):12pt, Header rows, all data rows, subtotal rows and total rows in tables with no subtotals: 10pt ")]
    reportvalidateheader ,
    [Description("Font should be Calibri through reports, consistent Font. ")]
    reportvalidatecalibirifont ,
    [Description("Reports requiring smaller font size to allow a larger range of data to be presented, font size can be decreased by 2pts each in each category (12pt, 10pt, 8pt), and font sizes smaller than 8pt should not be used as they are very difficult to read. ")]
    reportvalidatesmallfontsizes,
    [Description("Validate that Sorting/Ordering should be done on the report side, and not on server side, in the datasets ")]
    reportvalidatereportsidesortingandordering,
    [Description("Validate the use of Source Field alias. This should be done on the report side in the datasets, in field headers to allow for field to source mappings. ")]
    reportvalidateuseofsourcefieldalias,
    [Description("Titles, section titles, header rows, all subtotal, total and grand total rows and columns and the primary row label column should be bold. ")]
    reportvalidateboldtitlesandtotals,
    [Description("Header row and all subtotal/total/grand total rows:  As displayed above, the header row and all subtotal/total/grand total rows should be Light Grey, 80% tint. ")]
    reportvalidateheaderandtotalrowscolorandtint,
    [Description("1 pt line width should be used for all table and matrix borders. ")]
    reportvalidatelineseparatatorfortablematrix,
    [Description("Header row text should be centered in each column with an exception (as shown) when the header for the column containing row labels within a table is used as a title.  In this case, this cell should be left-aligned. ")]
    reportvalidateheaderrowlocation,
    [Description("Numerical data values within the report, including subtotals, totals and grand totals should be right-aligned. ")]
    reportvalidatenumericaldataalignment,
    [Description("All row labels, other than the header row, should be left-aligned; in tables where row labels indicate a parent-child hierarchy, each successive sub-level should be indented 10pt.  (Ex. Parent – 0pt; Child 1 – 10pt; Child 2 – 20pt; etc.) ")]
    reportvalidaterowlabelalignment,
    [Description("Format Numbers:  1,234,567 – Cells with values of 0 should display the 0 rather than a blank.  This can be manually configured using the number format #,##0 ")]
    reportvalidatenumberformat,
    [Description("Format Dates:  Jan 1900 – This can be manually configured using the date format MMM YYYY, if the day, month and year are required, the format should be 01/01/1900.  This can be manually configured using MM/DD/YYYY. ")]
    reportvalidatedateformat,
    [Description("Format Currency:  $1,234,567 or ($1,234,567) – Dollar amounts should not include cents unless specifically required for business use.  Currency format can be manually configured as $#,##0_);[Red]($#,##0). ")]
    reportvalidatecurrencyformat,
    [Description("Format Percentages:  12% - Percentages should be whole numbers unless decimal places are specifically required for business use.  Formatting can be manually configured as 0%. ")]
    reportvalidatepercentageformat,
    [Description("For new reports, parameters must be used on the report side, against a cached dataset or cached report.  This is a change to the normal operating procedures of the past, where packages were used to “stage” data and the parameters were on the query side. ")]
    reportvalidatenewreportparameters,
    [Description("Data source must be a Shared Datasource ")]
    reportvalidatedatasourceisshared,    
    [Description("Validate Table Naming Convention.  Table name with no underscores, spaces or special characters.   i.e.- (FinaldocsRPT.dbo.BondRiskMatrix)")]
    sqlsprocvalidatenamingconvention,
    [Description("All columns that represent the same data across tables should have the same name and data types")]
    sqlsprocvalidatecolumnnameanddatatype,
    [Description("Column names with no underscores, no spaces or special characters.    i.e.- ([LoanNbr/ DescID)")]
    sqlsprocvalidatecoulumnnamespecialchars,
    [Description("Best practice before creating new table in dev.  Communicate with the DBA for approval on new table, the use of primary key and if table needs to have Clustered/NonClustered Index or Unique Index.")]
    sqlsprocvalidatenewtablebestpractice,
    [Description("Table has a Clustered Index")]
    sqlsprocvalidatetableclusteredindexexists,
    [Description("Validate SP standard naming convention.  Stored Procedure name with no underscores, spaces or special characters. i.e.- (jobDefaultAssignment.sql/SalabilityShippingRpt.sql )")]
    sqlsprocvalidatesptandardnamingconv,
    [Description("Validate that all T-SQL key words are full uppercase but are not limited to the following:    This is to insure optimized, readable and consistent code in following the query standard.    i.e. - (INSERT INTO/ SELECT) ")]
    sqlsprocvalidatetsqlkeywordstandards,
    [Description("Do NOT use of (SELECT *) statement")]
    sqlsprocvalidatnonuserofwildcardselect,
    [Description("All columns must be added on INSERT INTO TABLE and on CREATE #Temp TABLE.")]
    sqlsprocvalidateinsertcolumnsadded,
    [Description("DISTINCT clause should be used with not more than 3 or 4 columns.  More columns with DISTINCT clause affect the query performance also indicates duplicates records are not being handled properly ")]
    sqlsprocvalidateuseofdistincton3or4columns,
    [Description("Do NOT negatives (NOT AND <> ) in WHERE clause.  Using this criteria is not optimize ")]
    sqlsprocvalidatenonuseofnegativesinwhere,
    [Description("Validate GROUP BY the way it is used:  (SUM(),MIN(),COUNT(),AVG().   Use only to obtain unique record identifier.  Avoid the use of GROUP BY without aggregate function to eliminate duplicate records. ")]
    sqlsprocvalidategroupbyuse,
    [Description("Validate the proper use of MAX/MIN and GROUP BY  to get the first or last record.  Avoid using it,  INSTEAD, use ROW_NUMBER")]
    sqlsprocvalidateminmaxandgroupbyuse,
    [Description("Do NOT use any ## Global Temp tables")]
    sqlsprocvalidatenoglobaltemptables,
    [Description("Validate the proper use of fully qualified name in SELECT queries in accessing objects from different tables or database.  (i.e. ServicingIntegrationRPT.dbo.SILoanMaster)")]
    sqlsprocvalidatefdqnonmultitableselect,
    [Description("Validate the use of WITH (NOLOCK). i.e. -  ( SELECT LoanMasterID FROM  dbo.SILoanMaster  WITH (NOLOCK) ")]
    sqlsprocvalidatewithnolockuse,
    [Description("Validate the proper use of WHERE/JOIN clause the way it is utilize.  Indention and white space to clearly display parenthetical and logical nesting levels. ")]
    sqlsprocvalidateproperuseofwherejoin,
    [Description("Validate the use if CASE STATEMENT:  Use CASE STATEMENT in place of 'OR', Less room for errors and easier to read. ")]
    sqlsprocvalidatecasestatmentuse,
    [Description("Do not use of alias on source columns. Avoid using it, INSTEAD, do  column formatting to display within SQL. ")]
    sqlsprocvalidatenonuseofaliasonsourcecolumns,
    [Description("Best practice to Add/Note criteria in business terms within the code where it's used.      i.e. -(SELECT DescID FROM  DocManRPT.dbo.SILoanEvent  WITH (NOLOCK)    WHERE DescID19   --319--Default Assignment Not Required ")]
    sqlsprocvalidatenotesforbusinessterms,
    [Description("Do NOT use UDF's (User Defined Function) within the WHERE clause.  (avoid anywhere if possible) ")]
    sqlsprocvalidatenonuseofudfsinwhere,
    [Description("Validate that SET QUOTED_IDENTIFIER ON clause is used. It should not be OFF ")]
    sqlsprocvalidatesetquotedidentifieron,
    [Description("Run Actual Execution Plan to check the performance of the select query.  Check the Estimated Operation I/O Cost.  Good performance should be less than 50% on the Estimated Operation Cost. The lower the I/O cost the more efficient of the operation. ")]
    sqlsprocvalidate,
    [Description("Check and validate if there's a need to create Clustered/NonClustered index or view to improve query performance.  Coordinate with the DBA Team. ")]
    sqlsprocvalidateclustered,
    [Description("Check and validate if there's a need to create Clustered/NonClustered index or view to improve query performance.  Coordinate with the DBA Team. ")]
    sqlcreatealtervalidateclustered,
    [Description("Check and validate if there's a need to create Clustered/NonClustered index or view to improve query performance.  Coordinate with the DBA Team. ")]
    sqlfunctionvalidateclustered,
    [Description("Check and validate if there's a need to create Clustered/NonClustered index or view to improve query performance.  Coordinate with the DBA Team. ")]
    sqlviewvalidateclustered,
    [Description("Validate the back out script on new and modified scripts/views/functions ")]
    backoutsqlvalidateexistsonnewitems,
    [Description("Naming convention of the backout script is correct ")]
    backoutsqlvalidatenamingconvention,
    [Description("Naming convention of the Shared Dataset is correct ")]
    shareddatasetvalidatenamingconvention,
    }
}
