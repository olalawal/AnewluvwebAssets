﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace WellsFargo.Promotion.Domain.Data
{
    public enum  promoterusernameenum
    {
        [Description("Select an item")]
        notset,
    [Description("Travis Hoff")]
        thoff,
    [Description("Marilou Nocon")]
    mnocon,
    [Description("John Mylabathula")]
    jmylabathula,
    [Description("Naveen Chaitanya")]
    nchaitanya
    }
}
