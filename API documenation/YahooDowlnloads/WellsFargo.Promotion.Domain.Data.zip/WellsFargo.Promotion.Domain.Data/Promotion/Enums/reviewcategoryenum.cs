﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace WellsFargo.Promotion.Domain.Data
{
    public enum  reviewcategoryenum
    {
        [Description("Select an item")]
        notset,
    [Description("SQL script")]  
    sqlsproc,
    [Description("SQL Create/Alter script")]
    sqlcreatealter,
    [Description("SQL Function")]
    sqlfunction,
    [Description("SQL View")]
    sqlview,
    [Description("SQL Backout script")]
    backoutsql,
    [Description("Package")]
    package,
    [Description("Report")]
    report,   
    [Description("Shared Dataset")]
    shareddataset
    }
}
