﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace WellsFargo.Promotion.Domain.Data
{
    public enum  promoterloginenum
    {
        [Description("Select an item")]
        notset,
    [Description("thoff")]
        thoff,
    [Description("U173523")]
    mnocon,
    [Description("U184979")]
    jmylabathula,
    [Description("U167454")]
    nchaitanya
    }
}
