﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace WellsFargo.Promotion.Domain.Data
{
    public enum  promotionobjectfiletypeenum
    {
        [Description("Select an item")]
        notset,
    [Description("sql")]
     script,
    [Description("dtsx")]
    package,
    [Description("rdl")]
    report,   
    [Description("rsd")]
    shareddataset
    }
}
