﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace WellsFargo.Promotion.Domain.Data
{
    public enum statusenum
    {
        [Description("Select A Status")]
        notset,   
     [Description("NA")]
        na,   
    [Description("Pass")]
    pass,
    [Description("Fail")]
    fail

    }
}
