﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace WellsFargo.Promotion.Domain.Data
{
    public enum scripttypeenum
    {
     [Description("Select an item")]
     notset,   
    [Description("Create/Alter Script")]
    changealterscript,
    [Description("Function")]
    function,
    [Description("View")]
    view,
    [Description("Sproc")]
    sproc,
    [Description("Backout Script")]
    backoutscirpt

    }
}
