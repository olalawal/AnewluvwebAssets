﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace WellsFargo.Promotion.Domain.Data
{
    public enum  enviromentenum
    {
        [Description("Select an item")]
        notset ,
    [Description("Development")]  
    dev,
    [Description("Quality Assurance")]
    qa,
    [Description("Uat")]
    uat,
    [Description("Production")]
    prod
    }
}
