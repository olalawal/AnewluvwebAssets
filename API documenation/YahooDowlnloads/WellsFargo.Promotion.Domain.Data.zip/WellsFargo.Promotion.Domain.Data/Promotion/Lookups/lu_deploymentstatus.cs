﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WellsFargo.Domain.Promotion
{
    //hopefully we can do away with this and share statuses with review
    public class lu_deploymentstatus
    {
        public int id { get; set; }       
        public string description { get; set; }
        public DateTime? adddate { get; set; }
        public DateTime? deactivedate { get; set; }
        public bool? active { get; set; }
        public virtual deployment deployment { get; set; }
    }
}
