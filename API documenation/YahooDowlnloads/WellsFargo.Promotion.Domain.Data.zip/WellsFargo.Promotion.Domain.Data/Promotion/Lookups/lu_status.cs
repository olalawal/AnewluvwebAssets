﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace  WellsFargo.Promotion.Domain.Data
{
    [DataContract(Namespace = "")]
    public class lu_status
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public string description { get; set; }
        [DataMember]
        public DateTime? adddate { get; set; }
        [DataMember]
        public DateTime? deactivedate { get; set; }
        [DataMember]
        public bool? active { get; set; }
       // [DataMember]
        //public virtual review review { get; set; }
        //[DataMember]
       // public virtual reviewhistory reviewhistory { get; set; }
        //[DataMember]
       // public virtual deployment deployment { get; set; }
        //[DataMember]
        //public virtual deploymenthistory deploymenthistory { get; set; }
       // [DataMember]
       // public virtual promotionobject promotionobject { get; set; }
        //[DataMember]
       // public virtual promotionobjecthistory promotionobjecthistory { get; set; }
    }
}
