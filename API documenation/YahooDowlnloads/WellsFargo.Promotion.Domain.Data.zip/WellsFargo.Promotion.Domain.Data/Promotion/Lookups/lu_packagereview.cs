﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WellsFargo.Domain.Promotion
{
    public class lu_packagereview
    {
        public int id { get; set; }
        public int order { get; set; }
        public string name { get; set; }
        public DateTime? adddate { get; set; }
        public DateTime? deactivedate { get; set; }
        public bool? active { get; set; }
        public virtual lu_reviewtype reviewtype { get; set; }
        public virtual review review { get; set; }
    }
}
