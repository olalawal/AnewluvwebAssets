﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace WellsFargo.Promotion.Domain.Data
{
    [DataContract(Namespace = "")]
    public class lu_reviewtype
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int order { get; set; }
        [DataMember]
        public string description { get; set; }
        [DataMember]
        public DateTime? adddate { get; set; }
        [DataMember]
        public DateTime? deactivedate { get; set; }
          [DataMember]
        public bool? active { get; set; }
          [DataMember]
        public int category_id { get; set; }
          [DataMember]
        public virtual lu_reviewcategory  category { get; set; }
       // [DataMember]
      //  public virtual lu_reviewtype reviewtype { get; set; }
       // [DataMember]
       // public virtual lu_promotionobjecttype objecttype { get; set; }
       // [DataMember]
      //  public virtual review review { get; set; }
    }
}
