﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace WellsFargo.Promotion.Domain.Data
{
     [DataContract(Namespace = "")]
    public class lu_promoter
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int order { get; set; }
        [DataMember]
        public string userlogin { get; set; }
        [DataMember]
        public string username { get; set; }        
        [DataMember]
        public DateTime? adddate { get; set; }
        [DataMember]
        public DateTime? deactivedate { get; set; }
        [DataMember]
        public bool? active { get; set; }
        public virtual promotionobject promotionobject { get; set; }
        //[DataMember]
        //public virtual promotionobjecthistory promotionobjecthistory { get; set; }
    }
}
