﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace WellsFargo.Promotion.Domain.Data
{
    [DataContract(Namespace = "")]
    public class lu_promotionobjecttype
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int order { get; set; }
        [DataMember]
        public string description { get; set; }
        [DataMember]
        public int category_id  { get; set; }
       [DataMember]  
        public virtual lu_reviewcategory category { get; set; }

       [DataMember]
       public int filetype_id  { get; set; }
        [DataMember]      
        public virtual lu_promotionobjectfiletype filetype { get; set; }

        [DataMember]
        public int tablename_id  { get; set; }
        [DataMember]        
        public virtual lu_promotionobjecttablename tablename { get; set; }

        [DataMember]
        public int? scripttype_id { get; set; }
        [DataMember]        
        public virtual lu_scripttype scripttype { get; set; }
        [DataMember]
        public DateTime? adddate { get; set; }
        [DataMember]
        public DateTime? deactivedate { get; set; }
        [DataMember]
        public bool? active { get; set; }
       // [DataMember]
        [IgnoreDataMember]
        public virtual ICollection<promotionobject> promotionobjects { get; set; }
        
    }
}
