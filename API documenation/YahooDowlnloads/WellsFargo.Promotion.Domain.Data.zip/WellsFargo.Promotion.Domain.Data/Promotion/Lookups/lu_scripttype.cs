﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace WellsFargo.Promotion.Domain.Data
{
    [DataContract(Namespace = "")]
    public class lu_scripttype
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int order { get; set; }
        [DataMember]
        public string description { get; set; }
        [DataMember]
        public DateTime? adddate { get; set; }
        [DataMember]
        public DateTime? deactivedate { get; set; }
        [DataMember]
        public bool? active { get; set; }
        //[DataMember]
       // public virtual lu_promotionobjecttype promotionobjecttype { get; set; }
    }
}
