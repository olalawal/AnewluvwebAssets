﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using WellsFargo.Promotion.Services.Contracts;
      
using System.ServiceModel.Activation;
using WellsFargo.Promotion.Domain.Data;
using WellsFargo.DataAccess.Interfaces;
//using WellsFargo.Promotion.Domain.Extentions;
using WellsFargo.Promotion.Domain.Data.SurfManagement;
using WellsFargo.Promotion.Domain.Data.SurfManagement.ViewModels;


namespace WellsFargo.Promotion.Services
{
   
    //TO do with this new patter either find a way to make extention methods use the generic repo dict in EFUnitOfWork or 
    //MOve the remaining ext method methods into this service layer that uses the EF unit of work
    //TO do also make a single Update method generic and implement that for the rest of the Repo saves.
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "MembersService" in both code and config file together.
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]  
    public class SurfManagementService : ISurfManagementService 
    {
        //if our repo was generic it would be IPromotionRepository<T>  etc IPromotionRepository<reviews> 
        //private IPromotionRepository  promotionrepository;

        IUnitOfWork _unitOfWork;
       

        public SurfManagementService(IUnitOfWork unitOfWork)
            {

                if (unitOfWork == null)
                {
                    throw new ArgumentNullException("unitOfWork", "unitOfWork cannot be null");
                }

                if (unitOfWork == null)
                {
                    throw new ArgumentNullException("dataContext", "dataContext cannot be null");
                }

                //promotionrepository = _promotionrepository;
                _unitOfWork = unitOfWork;
              //  _apikey  = HttpContext.Current.Request.QueryString["apikey"];
             //   throw new System.ServiceModel.Web.WebFaultException<string>("Invalid API Key", HttpStatusCode.Forbidden);
          
            }

        


        //TO do Cache this on client or in appfabric or something
        //5-10-2013 olawal
        public List<surfmanagement> getactivesurfs() 
        {
            _unitOfWork.DisableProxyCreation = true;
            using (var db = _unitOfWork)
            {
                return db.GetRepository<surfmanagement>().Find().OfType<surfmanagement>()
                    .Where(p => p.status != "Completed" || p.status != "Canceled").Take(100).OrderBy(p => p.opendate).ToList();
            }
        }

        public List<surfviewmodel> filteractivesurfsbyid(string filter)
        {
            //thro this error using service eror handling 
            //if filter.Length < 2 return "Enter at least two characters";
            var test = new  List <surfviewmodel>();
            using (_unitOfWork)
          {
              //while (_unitOfWork..State != System.Data.ConnectionState.Closed)
              //{
              //    System.Threading.Thread.Sleep(500);
              //}


                _unitOfWork.DisableLazyLoading  = true;
               _unitOfWork.DisableProxyCreation = true;
               var items = _unitOfWork.GetRepository<surfmanagement>().Find().OfType<surfmanagement>().Where(z => z.category == "MIS Reporting").ToList()
                            .Where(p => p.status != "Completed" || p.status != "Canceled").ToList();
                           
                             
                             
                       var dd = from c in items  select new surfviewmodel
                            {
                                id = c.id.ToString(),
                                opendate = c.opendate,
                                summary = c.summary

                            };

              //   var count = items.Count();

                test = dd.Where(p => p.id.Contains(filter)).Take(100).OrderBy(p => p.opendate).ToList();
                // test = items.Take(1).ToList();

                
            return test;
        }
          
        }


        

    }
}
