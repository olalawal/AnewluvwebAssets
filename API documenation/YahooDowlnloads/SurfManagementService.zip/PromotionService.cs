﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using WellsFargo.Promotion.Services.Contracts;

using System.ServiceModel.Activation;
using WellsFargo.Promotion.Domain.Data;
using WellsFargo.DataAccess.Interfaces;
//using WellsFargo.Promotion.DataAccess.Extentions;
using WellsFargo.Promotion.Domain.Data.SurfManagement.ViewModels;


namespace WellsFargo.Promotion.Services
{

    //TO do with this new patter either find a way to make extention methods use the generic repo dict in EFUnitOfWork or 
    //MOve the remaining ext method methods into this service layer that uses the EF unit of work
    //TO do also make a single Update method generic and implement that for the rest of the Repo saves.
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "MembersService" in both code and config file together.
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall, ConcurrencyMode = ConcurrencyMode.Multiple)]  
    public class PromotionService : IPromotionService
    {
        //if our repo was generic it would be IPromotionRepository<T>  etc IPromotionRepository<reviews> 
        //private IPromotionRepository  promotionrepository;

        IUnitOfWork _unitOfWork;


        public PromotionService(IUnitOfWork unitOfWork)
        {

            if (unitOfWork == null)
            {
                throw new ArgumentNullException("unitOfWork", "unitOfWork cannot be null");
            }

            if (unitOfWork == null)
            {
                throw new ArgumentNullException("dataContext", "dataContext cannot be null");
            }

            //promotionrepository = _promotionrepository;
            _unitOfWork = unitOfWork;
            //disable proxy stuff by default
            //_unitOfWork.DisableProxyCreation = true;
            //  _apikey  = HttpContext.Current.Request.QueryString["apikey"];
            //   throw new System.ServiceModel.Web.WebFaultException<string>("Invalid API Key", HttpStatusCode.Forbidden);

        }





        //main promotionobject service impelematations

        #region "Promotion object related service calls

        public List<promotionobject> getpromotionobjectsbysurfandstatus(string surfstring, string  status)
        {
            _unitOfWork.DisableProxyCreation = true;
            using (var db = _unitOfWork)
            {
                int? statusconverted = Convert.ToInt32(status); // statusenum.notset;
               // var convertedsurfid = Convert.ToInt32(surfid);
               // (p.status_id == statusconverted | p.status_id != (int)statusenum.pass) &&
                if (statusconverted == 0) statusconverted = null;
                IRepository<promotionobject> repo = db.GetRepository<promotionobject>();
                var promotionobjects = repo.Find().OfType<promotionobject>().Where(p => (p.status_id.Equals(statusconverted) | p.status_id != (int)statusenum.pass) && p.surfstring == surfstring).ToList();

                  var promotionobjectstoreturn = new List<promotionobject>();
                  if (promotionobjects.Count() > 0)
                  {
                      foreach (promotionobject item in promotionobjects)
                      {
                          // item.TDocRecon = dd;
                          item.detail = db.GetRepository<promotionobjectdetail>().Find().OfType<promotionobjectdetail>().Where(p => p.id == item.id).FirstOrDefault();

                          item.status = db.GetRepository<lu_status>().Find().OfType<lu_status>().Where(p => p.id == item.status_id).FirstOrDefault();

                          item.promoter = db.GetRepository<lu_promoter>().Find().OfType<lu_promoter>().Where(p => p.id == item.promoter_id).FirstOrDefault();

                          item.objecttype = db.GetRepository<lu_promotionobjecttype>().Find().OfType<lu_promotionobjecttype>().Where(p => p.id == item.objecttype_id).FirstOrDefault();
                          //get the property values if any
                          // item.TDocSecRowAttributesPropValues = propertyvalues.Where(p => p. == item).ToList();
                          //foreach (TDocSecRowAttributesProp attributeproperty in item.TDocSecRowAttributes.TDocSecRowAttributesProp)
                          //{
                          //    //{"Invalid column name 'TDocSecRowAttributeValues_DocSecRowAttrValId'."}
                          //    List<TDocSecRowAttributesPropValues> test = new List<TDocSecRowAttributesPropValues>();
                          //    //  item.TDocSecRowAttributes.TDocSecRowAttributesProp = propertyvalues.Where(p => p.DocSecRowAttrValId  == attributeproperty.DocSecRowAttrPropId)
                          //}


                          promotionobjectstoreturn.Add(item);
                      }
                  }

                  return promotionobjectstoreturn;
            }
        }

        public List<promotionobject> getpromotionobjectsbypromotionobjecttype(promotionobjecttypeenum type)
        {
            _unitOfWork.DisableProxyCreation = true;
            using (var db = _unitOfWork)
            {
                IRepository<promotionobject> repo = db.GetRepository<promotionobject>();
                //var result =  _unitOfWork.GetRepository<promotionobject>().Find().OfType<promotionobject>();
                //  return repo.Find().OfType<promotionobject>().Where(p => p.promotionobjecttype.id == (int)type).ToList();
                return null;

            }

        }
        public promotionobject getpromotionobjectbypromotionobjectid(string promotionobjectid)
        {
            _unitOfWork.DisableProxyCreation = true;
            using (var db = _unitOfWork)
            {
                var convertedpromotionobjectid = Convert.ToInt32(promotionobjectid);
                IRepository<promotionobject> repo = db.GetRepository<promotionobject>();
                var item = repo.Find().SingleOrDefault(p => p.id == convertedpromotionobjectid);

                if (item != null)
                {

                    // item.TDocRecon = dd;
                    item.detail = db.GetRepository<promotionobjectdetail>().Find().OfType<promotionobjectdetail>().Where(p => p.id == item.id).FirstOrDefault();

                    item.status = db.GetRepository<lu_status>().Find().OfType<lu_status>().Where(p => p.id == item.status_id).FirstOrDefault();

                    item.promoter = db.GetRepository<lu_promoter>().Find().OfType<lu_promoter>().Where(p => p.id == item.promoter_id).FirstOrDefault();

                    item.objecttype = db.GetRepository<lu_promotionobjecttype>().Find().OfType<lu_promotionobjecttype>().Where(p => p.id == item.objecttype_id).FirstOrDefault();
                }

                return item;
            }
        }
        public List<promotionobject> getpromotionobjectsbyreviewcategory(reviewcategoryenum category)
        {
            _unitOfWork.DisableProxyCreation = true;
            using (var db = _unitOfWork)
            {
                IRepository<promotionobject> repo = db.GetRepository<promotionobject>();
                // return repo.Find().OfType<promotionobject>().Where(p => p.promotionobjecttype.category.id == (int)category).ToList(); ;
                return null;
            }
        }
        public List<promotionobject> getpromotionobjectsbystatus(statusenum status)
        {
            _unitOfWork.DisableProxyCreation = true;
            using (var db = _unitOfWork)
            {
                IRepository<promotionobject> repo = db.GetRepository<promotionobject>();
                return repo.Find().OfType<promotionobject>().Where(p => p.status.id == (int)status).ToList();
            }
        }

        public List<promotionobject> getallpromotionobjects()
        {

            _unitOfWork.DisableProxyCreation = true;
            using (var db = _unitOfWork)
            {
                // List<promotionobject> finalresult = new List<promotionobject>();
                IRepository<promotionobject> repo = db.GetRepository<promotionobject>();
                return repo.Find().OfType<promotionobject>().ToList();

                //TO DO for some reason the detail is not being navigated ... add it here
                //TO DO do away with this shared key thing apply its own key and navigation props
                //if (dd.Count > 0)
                //{
                //    foreach (promotionobject item in dd)
                //    {
                //        item.detail = db.GetRepository<promotionobjectdetail>().Find().OfType<promotionobjectdetail>().Where(p => p.id == item.id).FirstOrDefault();
                //        //TO DO there is to promotion object type scafoled
                //        //type not scafolded due to bug in the database
                //        // item.promotionobjecttype = this.getobjecttypes().w  
                //        finalresult.Add(item);
                //    }
                //}
                //return finalresult;
            }
        }

        #endregion

        //Get history/Audit table data
        //5-3-2013 olawal uses generic repo implemeantion   
        #region "Promotion object history replated servcie calls"
        public List<promotionobjecthistory> getpromotionobjecthistbypromotionobjectid(int promotionobjectid)
        {
            _unitOfWork.DisableProxyCreation = true;
            using (var db = _unitOfWork)
            {
                IRepository<promotionobject> repo = db.GetRepository<promotionobject>();
                return repo.Find().OfType<promotionobjecthistory>().Where(p => p.promotionobject.id == promotionobjectid).OrderBy(s => s.timestamp).ToList();
            }

        }
        public List<promotionobjecthistory> getallpromotionobjecthist()
        {
            _unitOfWork.DisableProxyCreation = true;
            using (var db = _unitOfWork)
            {
                IRepository<promotionobject> repo = db.GetRepository<promotionobject>();
                return repo.Find().OfType<promotionobjecthistory>().ToList();
            }
        }

        #endregion

        //TO DO move code from extention methods into service code
        //Deployment service implemenations
        //TO DO maybe a separaterepo
        //Methods that pull stuff for  deployments
        #region "Deployment Related service calls"
        public List<deployment> getdeploymentsbypromotionobjectid(int promotionobjectid)
        {
            _unitOfWork.DisableProxyCreation = true;
            using (var db = _unitOfWork)
            {

                IRepository<deployment> repo = db.GetRepository<deployment>();
                return repo.Find().OfType<deployment>().Where(p => p.promotionobjectdetail.promotionobject.id == promotionobjectid).ToList();

            }
        }
        public List<deployment> getdeploymentsbydeploymenttype(deploymenttypeenum type)
        {
            _unitOfWork.DisableProxyCreation = true;
            using (var db = _unitOfWork)
            {
                IRepository<deployment> repo = db.GetRepository<deployment>();
                return repo.Find().OfType<deployment>().Where(p => p.status.id == (int)type).ToList();
            }
        }
        public List<deployment> getdeploymentsbyenviroment(enviromentenum enviroment)
        {
            _unitOfWork.DisableProxyCreation = true;
            using (var db = _unitOfWork)
            {
                IRepository<deployment> repo = db.GetRepository<deployment>();
                return repo.Find().OfType<deployment>().Where(p => p.status.id == (int)enviroment).ToList();
            }
        }
        public List<deployment> getalldeployments()
        {

            using (var db = _unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                IRepository<deployment> repo = db.GetRepository<deployment>();
                return repo.Find().OfType<deployment>().ToList();
            }
        }
        public List<deployment> getalldeploymentsbysurfid(int surfid)
        {

            using (var db = _unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                IRepository<deployment> repo = db.GetRepository<deployment>();
                return repo.Find().OfType<deployment>().Where(p => p.promotionobjectdetail.promotionobject.surf.id == surfid).ToList();


            }

        }
        public List<deployment> getalldeploymentsbydeveloper(string developer)
        {
            using (var db = _unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                IRepository<deployment> repo = db.GetRepository<deployment>();
                return repo.Find().OfType<deployment>().Where(p => p.promotionobjectdetail.developer == developer).ToList();

            }

        }
        #endregion


        //Update methods .... are on service layer since they implement 
        //Get history/Audit table data
        //5-3-2013 olawal uses generic repo implemeantion
        #region "Deplyment History related service calls
        public List<deploymenthistory> getdeploymenthistbypromotionobjectid(int promotionobjectid)
        {
            using (var db = _unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                return _unitOfWork.GetRepository<deploymenthistory>().Find().OfType<deploymenthistory>().
                    Where(p => p.deployment.promotionobjectdetail.promotionobject.id == promotionobjectid).OrderBy(s => s.timestamp).ToList();
            }

        }
        public List<deploymenthistory> getdeploymenthistbydeploymentid(int deploymentid)
        {
            using (var db = _unitOfWork)
            {
                return _unitOfWork.GetRepository<deploymenthistory>().Find().OfType<deploymenthistory>().
              Where(p => p.deployment.id == deploymentid).OrderBy(s => s.timestamp).ToList();

            }


        }
        public List<deploymenthistory> getalldeploymenthist()
        {
            using (var db = _unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                return _unitOfWork.GetRepository<deploymenthistory>().Find().OfType<deploymenthistory>().ToList();
            }



        }
        #endregion


        //main review service implematations
        //TO DO maybe a separaterepo
        //Methods that pull stuff for reviews
        #region "Review realated service calls"
        public List<review> getreviewsbypromotionobjectid(int promotionobjectid)
        {
            using (var db = _unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                IRepository<review> repo = db.GetRepository<review>();
                return repo.Find().OfType<review>().Where(p => p.promotionobjectdetail.promotionobject.id == promotionobjectid).ToList();
            }

        }




        public review getreviewsbyreviewid(int reviewid)
        {
            using (var db = _unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                IRepository<review> repo = db.GetRepository<review>();
                return repo.Find().OfType<review>().Where(p => p.id == reviewid).FirstOrDefault();
            }
        }

        public List<review> getreviewsbyreviewtype(reviewtypeenum type)
        {
            using (var db = _unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                IRepository<review> repo = db.GetRepository<review>();
                return repo.Find().OfType<review>().Where(p => p.reviewtype.id == (int)type).ToList();
            }
            //return _unitOfWork.GetRepository<review>().getreviewsbyreviewtype(type).ToList();

        }
        public List<review> getreviewsbyreviewcategory(reviewcategoryenum category)
        {
            using (var db = _unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                IRepository<review> repo = db.GetRepository<review>();
                //  return repo.Find().OfType<review>().Where(p => p.promotionobjectdetail.promotionobject.promotionobjecttype.category.id == (int)category).ToList();
                return null;
            }
            // return _unitOfWork.GetRepository<review>().getreviewsbyreviewcategory(category).ToList();
        }
        public List<review> getreviewsbystatus(statusenum status)
        {
            using (var db = _unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                IRepository<review> repo = db.GetRepository<review>();
                return repo.Find().OfType<review>().Where(p => p.status.id == (int)status).ToList();
            }
            //  return _unitOfWork.GetRepository<review>().getreviewsbystatus(status).ToList(); 
        }

        public List<review> getreviewsbynotesstring(string notes)
        {
            using (var db = _unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                IRepository<review> repo = db.GetRepository<review>();
                return repo.Find().OfType<review>().Where(p => p.detail.notes.Contains(notes)).ToList();
            }
            // return _unitOfWork.GetRepository<review>().getreviewsbynotesstring(notes).ToList();
        }
        public List<review> getallreviews()
        {
            using (var db = _unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                IRepository<review> repo = db.GetRepository<review>();
                return repo.Find().OfType<review>().ToList();
            }
            //  return _unitOfWork.GetRepository<review>().getallreviews().ToList();
        }

        #endregion

        #region "Surf related calls"

        public surf getsurfbysurfid(string surfid)
        {

            _unitOfWork.DisableProxyCreation = true;
            return _unitOfWork.GetRepository<surf>().Find().OfType<surf>().Where(p => p.surfid == surfid).FirstOrDefault();

        }

        public List<surfviewmodel> getpromotedsurfsfiltered(string filter)
        {
            _unitOfWork.DisableProxyCreation = true;
            //return
            using (var db = _unitOfWork)
            {
                var items = from c in db.GetRepository<surf>().Find().OfType<surf>()
                             .Where(p => p.promotionobjects.Count > 0).AsEnumerable()
                            select new surfviewmodel
                            {
                                id = c.surfid,
                                //opendate = 
                                summary = c.surfid

                            };

                // var test = items;
                //show all if nothingh matches filter filter is passed 

                var filtereditems = items.Where(p => p.id.Contains(filter)).Take(100).OrderBy(p => p.id).ToList();
                if (filtereditems.Count() > 0)
                {

                    return filtereditems.ToList();

                }
                else
                {
                    return items.Take(100).OrderBy(p => p.id).ToList();
                }
            }
        }
        #endregion
        //IEnumerable<Priority> GetTicketPriorities(){ return _unitOfWork.GetRepository<review>().getreviewsbypromotionobjectid(promotionobjectid).ToList(); }
        //Get history/Audit table data
        //5-3-2013 olawal uses generic repo implemeantion
        #region "Review history related service calls "
        public List<reviewhistory> getreviewhistbypromotionobjectid(int promotionobjectid)
        {
            _unitOfWork.DisableProxyCreation = true;
            return _unitOfWork.GetRepository<reviewhistory>().Find().OfType<reviewhistory>()
                .Where(p => p.review.promotionobjectdetail.promotionobject.id == promotionobjectid).OrderBy(s => s.timestamp).ToList();
        }
        public List<reviewhistory> getreviewhistbyreview(int reviewid)
        {
            _unitOfWork.DisableProxyCreation = true;
            return _unitOfWork.GetRepository<reviewhistory>().Find().OfType<reviewhistory>().
                Where(p => p.review.id == reviewid).OrderBy(s => s.timestamp).ToList().ToList();
        }
        public List<reviewhistory> getrallreviewhist()
        {
            _unitOfWork.DisableProxyCreation = true;
            return _unitOfWork.GetRepository<reviewhistory>().Find().OfType<reviewhistory>().ToList();
        }

        #endregion



        //TO do Cache this on client or in appfabric or something
        //5-3-2013 olawal YAY got this working with the generic repository
        #region "Lookup list service calls"
        public List<lu_reviewcategory> getreviewcategories()
        {
            _unitOfWork.DisableProxyCreation = true;
            using (_unitOfWork)
            {
                return _unitOfWork.GetRepository<lu_reviewcategory>().Find().OfType<lu_reviewcategory>().ToList();
            }
        }
        public List<lu_reviewtype> getreviewtypes()
        {
            _unitOfWork.DisableProxyCreation = true;
            using (_unitOfWork)
            {
                var dd =  _unitOfWork.GetRepository<lu_reviewtype>().Find().OfType<lu_reviewtype>().ToList();
                return dd;
            }
        }
        public List<lu_deploymenttype> getdeploymenttypes()
        {
            _unitOfWork.DisableProxyCreation = true;
            return _unitOfWork.GetRepository<lu_deploymenttype>().Find().OfType<lu_deploymenttype>().ToList();
        }
        public List<lu_promoter> getpromoters()
        {
            _unitOfWork.DisableProxyCreation = true;
            using (_unitOfWork)
            {
                return _unitOfWork.GetRepository<lu_promoter>().Find().OfType<lu_promoter>().ToList();
            }
        }
        public List<lu_promotionobjectfiletype> getfiletypes()
        {
            using (_unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                return _unitOfWork.GetRepository<lu_promotionobjectfiletype>().Find().OfType<lu_promotionobjectfiletype>().ToList();
            }
        }
        public List<lu_promotionobjecttablename> gettablenames()
        {
            using (_unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                return _unitOfWork.GetRepository<lu_promotionobjecttablename>().Find().OfType<lu_promotionobjecttablename>().ToList();
            }
        }
        public List<lu_promotionobjecttype> getobjecttypes()
        {
            using (_unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                var dd = _unitOfWork.GetRepository<lu_promotionobjecttype>().Find().OfType<lu_promotionobjecttype>().ToList();
                return dd;
            }
        }
        public List<lu_scripttype> getscripttypes()
        {
            using (_unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                return _unitOfWork.GetRepository<lu_scripttype>().Find().OfType<lu_scripttype>().ToList();
            }
        }

        public List<lu_status> getstatuses()
        {
            using (_unitOfWork)
            {
                _unitOfWork.DisableProxyCreation = true;
                return _unitOfWork.GetRepository<lu_status>().Find().OfType<lu_status>().ToList();
            }
        }
        #endregion


        #region "Add update methods"

        public bool addpromotionobject(promotionobject promotionobject)
        {






            using (var db = _unitOfWork)
            {
                db.IsAuditEnabled = false; //do not audit on adds
                using (var transaction = db.BeginTransaction())
                {
                    try
                    {
                        //TO DO do away with this when we remove SURF from this model since its stored somehwe else
                        //check if there is mathcing surf if not add one 
                        if (this.getsurfbysurfid(promotionobject.surfstring) == null)
                        {
                            //add the surf 
                            IRepository<surf> surfrepository = db.GetRepository<surf>();
                            db.Add(new surf { surfid = promotionobject.surfstring });
                            int i2 = db.Commit();
                            // transaction.Commit();                          
                        }

                        //now add the surf to the promotion
                        promotionobject.surf = (this.getsurfbysurfid(promotionobject.surfstring));
                        //get the actual linkage to the promotion object type
                        var actualpromotionobjecttype = db.GetRepository<lu_promotionobjecttype>();
                        //   .Find().OfType<lu_promotionobjecttype>().Where(p => p.description == promotionobject.promotionobjecttype.description).FirstOrDefault();
                        //      promotionobject.promotionobjecttype = actualpromotionobjecttype;
                        //get actual linkage to the status
                        var actualstatus = db.GetRepository<lu_status>()
                        .Find().OfType<lu_status>().Where(p => p.description == promotionobject.status.description).FirstOrDefault();

                        IRepository<promotionobject> repository = db.GetRepository<promotionobject>();
                        db.Add(promotionobject);
                        int i = db.Commit();
                        transaction.Commit();
                        return (i > 0);
                    }
                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
            return false;
        }
        public bool addpromotionobjectbatch(List<promotionobject> promotionobjects)
        {

            using (var db = _unitOfWork)
            {
                db.IsAuditEnabled = false; //do not audit on adds
                using (var transaction = db.BeginTransaction())
                {
                    try
                    {
                        IRepository<promotionobject> repository = db.GetRepository<promotionobject>();

                        //here begins the adding of the objects.
                        foreach (promotionobject item in promotionobjects)
                        {

                            //TO DO do away with this when we remove SURF from this model since its stored somehwe else
                            //check if there is mathcing surf if not add one 
                            if (this.getsurfbysurfid(item.surfstring) == null)
                            {
                                //add the surf 
                                IRepository<surf> surfrepository = db.GetRepository<surf>();
                                db.Add(new surf { surfid = item.surfstring });
                                int i2 = db.Commit();
                                // transaction.Commit();                          
                            }

                            //now add the surf to the promotion
                            item.surf_id = db.GetRepository<surf>().Find().OfType<surf>().Where(p => p.surfid == item.surfstring).FirstOrDefault().id;  // this.getsurfbysurfid(item.surfstring));
                            //get the actual linkage to the promotion object type
                            // var actualpromotionobjecttype = 
                            // item.objecttype_id = db.GetRepository<lu_promotionobjecttype>().Find().OfType<lu_promotionobjecttype>().Where(p => p.id == item.objecttype_id).FirstOrDefault();
                            // item.promotionobjecttype = actualpromotionobjecttype;

                            //manage order here - if there are orders already append this item to the end 
                            var currentsurfpromotionobjects = db.GetRepository<promotionobject>().
                                Find().OfType<promotionobject>().Where(p => p.surf.surfid == item.surfstring).OrderBy(z => z.order).ToList();
                            if (currentsurfpromotionobjects.Count() > 0)
                            {
                                //increment the order based on the last item 
                                item.order = currentsurfpromotionobjects.Last().order + 1;
                            }


                            //get actual linkage to the status
                            // var actualstatus = db.GetRepository<lu_status>()
                            // .Find().OfType<lu_status>().Where(p => p.description == item.status.description).FirstOrDefault();
                            db.Add(item);
                        }

                        int i = db.Commit();
                        transaction.Commit();
                        return (i > 0);
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        public bool addreview(review review)
        {

            using (var db = _unitOfWork)
            {
                db.IsAuditEnabled = false; //do not audit on adds
                using (var transaction = db.BeginTransaction())
                {
                    try
                    {
                        IRepository<review> repository = db.GetRepository<review>();
                        db.Add(review);
                        int i = db.Commit();
                        transaction.Commit();
                        return (i > 0);
                    }
                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }

                }

            }
            return false;
        }
        public bool adddeployment(deployment deployment)
        {

            using (var db = _unitOfWork)
            {
                db.IsAuditEnabled = false; //do not audit on adds
                using (var transaction = db.BeginTransaction())
                {
                    try
                    {
                        IRepository<deployment> repository = db.GetRepository<deployment>();
                        db.Add(deployment);
                        int i = db.Commit();
                        transaction.Commit();
                        return (i > 0);
                    }
                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }

                }

            }
            return false;
        }
        public bool addsurf(surf surf)
        {

            using (var db = _unitOfWork)
            {
                db.IsAuditEnabled = false; //do not audit on adds
                using (var transaction = db.BeginTransaction())
                {
                    try
                    {
                        IRepository<surf> repository = db.GetRepository<surf>();
                        db.Add(surf);
                        int i = db.Commit();
                        transaction.Commit();
                        return (i > 0);
                    }
                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }

                }

            }
            return false;
        }
        public bool updatepromotionobject(promotionobject promotionobject)
        {
            using (var db = _unitOfWork)
            {
                db.IsAuditEnabled = true;
                using (var transaction = db.BeginTransaction())
                {
                    try
                    {

                        //get existing item
                        var existingitem = db.GetRepository<promotionobject>().Find().OfType<promotionobject>().Where(p => p.surfstring == promotionobject.surfstring && p.id == promotionobject.id ).FirstOrDefault();
                        if (existingitem == null) return false;


                        //temp fix for metadata until we automate it
                        bool surfupdated = false;

                        var PromoterRepository = db.GetRepository<lu_promoter>() ; //.Find().OfType<surf>()
                    
                        //if this was a change the user must have had a settlement agent assigned before 
                        if (promotionobject.promoter != null && promotionobject.promoter .userlogin  != null)
                        {


                            if (PromoterRepository.Find().OfType<lu_promoter>().Where(p => p.userlogin  == promotionobject.promoter.userlogin).FirstOrDefault() == null)
                            {
                                //add the settlementagent 

                                db.Add(promotionobject.promoter);
                                int ssettlementagentid = db.Commit();
                                //transaction.Commit();  
                                surfupdated = true;
                            }
                            //get the new settlementagent id and map
                            promotionobject.promoter_id = PromoterRepository.Find().OfType<lu_promoter>().Where(p => p.userlogin  == promotionobject.promoter.userlogin ).FirstOrDefault().id ;

                        }

                        //in this case they could be resetting the settlement agent so detatch it                       
                        else if (promotionobject.promoter != null && promotionobject.promoter_id  != existingitem.promoter_id )
                        {
                            existingitem.promoter_id = promotionobject.promoter_id ;
                            existingitem.promoter = null;
                            surfupdated = true;
                        }


                        //in this case they could be resetting the settlement agent so detatch it                       
                        else if (promotionobject.status    != null && promotionobject.status_id  != existingitem.status_id)
                        {
                            existingitem.status_id  = promotionobject.status_id ;
                            existingitem.status  = null;
                            surfupdated = true;
                        }

                          //in this case they could be resetting the settlement agent so detatch it                       
                        else if (promotionobject.detail.reviewer  != null && promotionobject.detail.reviewer  != existingitem.detail.reviewer )
                        {
                            existingitem.detail.reviewer  = promotionobject.detail.reviewer ;                            
                            surfupdated = true;
                        }



                        //TO DO add these missing feidlds until the chnage tracking is done
                        if (surfupdated == true)
                        {
                           // existingitem.ModifyBy = item.ModifyBy;
                           // existingitem.ModifyDate = item.ModifyDate;
                            existingitem.statusdate = promotionobject.statusdate;
                        }

                        // IRepository<promotionobject> repository = db.GetRepository<promotionobject>();
                        db.Update(existingitem);
                        int i = db.Commit();
                        transaction.Commit();
                        return (i > 0);
                    }
                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
            return false;
        }
        public bool updatereview(review review)
        {

            using (var db = _unitOfWork)
            {
                db.IsAuditEnabled = true;
                using (var transaction = db.BeginTransaction())
                {
                    try
                    {
                        IRepository<review> repository = db.GetRepository<review>();
                        db.Update(review);
                        int i = db.Commit();
                        transaction.Commit();
                        return (i > 0);
                    }
                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }

                }

            }
            return false;
        }
        public bool updatedeployment(deployment deployment)
        {

            using (var db = _unitOfWork)
            {
                db.IsAuditEnabled = true;
                using (var transaction = db.BeginTransaction())
                {
                    try
                    {
                        // IRepository<deployment> repository = db.GetRepository<deployment>();
                        db.Update(deployment);
                        int i = db.Commit();
                        transaction.Commit();
                        return (i > 0);
                    }
                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }

                }

            }
            return false;
        }
        public bool updatesurf(surf surf)
        {

            using (var db = _unitOfWork)
            {
                db.IsAuditEnabled = false;
                using (var transaction = db.BeginTransaction())
                {
                    try
                    {
                        //IRepository<surf> repository = db.GetRepository<surf>();
                        db.Update(surf);
                        int i = db.Commit();
                        transaction.Commit();
                        return (i > 0);
                    }
                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }

                }

            }
            return false;
        }
        #endregion



    }
}
