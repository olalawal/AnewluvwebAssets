﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WellsFargo.Promotion.Domain.Data;
using WellsFargo.Promotion.Domain.Interfaces;

namespace WellsFargo.Promotion.Domain.Extentions
{
   public  static  class deploymentextentions
    {

         //public static IEnumerable<deployment> GetOrdersMatchingParams(this IRepository<deployment>, int param1, string param2)    
         //{         // Do query here and return the result    
         
         //} 

          //TO DO maybe a separaterepo
        //Methods that pull stuff for  deployments
        public  static  IEnumerable<deployment> getdeploymentsbypromotionobjectid(this IRepository<deployment> repo , int promotionobjectid )
        {

            return repo.Find().OfType<deployment>().Where(p => p.promotionobject.id == promotionobjectid);
        }
        public  static IEnumerable<deployment> getdeploymentsbydeploymenttype(this IRepository<deployment> repo,deploymenttypeenum type)
        {
            return repo.Find().OfType<deployment>().Where(p => p.status.id == (int)type);
        }
        public static IEnumerable<deployment> getdeploymentsbyenviroment(this IRepository<deployment> repo, enviromentenum enviroment)
        {
            return repo.Find().OfType<deployment>().Where(p => p.status.id == (int)enviroment);
        }
        public  static IEnumerable<deployment> getalldeployments(this IRepository<deployment> repo )
        {
            return repo.Find().OfType<deployment>();
        }
        public static IEnumerable<deployment> getalldeploymentsbysurfid(this IRepository<deployment> repo, int surfid)
        {
            return repo.Find().OfType<deployment>().Where(p => p.promotionobject.surf.id == surfid); ;
        }
        public static IEnumerable<deployment> getalldeploymentsbydeveloper(this IRepository<deployment> repo, string developer)
        {
            return repo.Find().OfType<deployment>().Where(p => p.promotionobject.detail.developer == developer);
        }
        

        //TO DO maybe a separaterepo
        //audit table stuff
        public static IEnumerable<deploymenthistory> getdeploymenthistbypromotionobjectid(this IRepository<deployment> repo, int promotionobjectid)
        {
            return repo.Find().OfType<deploymenthistory>().Where(p => p.deployment.promotionobject.id == promotionobjectid).OrderBy(s => s.timestamp);

        }
        public static IEnumerable<deploymenthistory> getdeploymenthistbydeploymentid(this IRepository<deployment> repo, int deploymentid)
        {
            return repo.Find().OfType<deploymenthistory>().Where(p => p.deployment.id == deploymentid).OrderBy(s => s.timestamp);

        }
        public  static IEnumerable<deploymenthistory> getalldeploymenthist(this IRepository<deployment> repo )
        {
            return repo.Find().OfType<deploymenthistory>();
        }


    }
}
