﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WellsFargo.Promotion.Domain.Data;
using WellsFargo.Promotion.Domain.Interfaces;

namespace WellsFargo.Promotion.Domain.Extentions
{
     public  static     class promotionobjectextentions
    {

         //  public  static  static IEnumerable<deployment> GetOrdersMatchingParams(this IRepository<promotionobject> repo, int param1, string param2)    
         //{         // Do query here and return the result    
         
         //} 


         public  static  IEnumerable<promotionobject> getpromotionobjectsbypromotionobjecttype(this IRepository<promotionobject> repo, promotionobjecttypeenum type)
        {


            return repo.Find().OfType<promotionobject>().Where(p => p.promotionobjecttype.id == (int)type);
        }
         public  static  promotionobject getpromotionobjectbypromotionobjectid(this IRepository<promotionobject> repo, int promotionobjectid)
        {

            return repo.Find().SingleOrDefault(p => p.id == promotionobjectid);
        }
         public  static  IEnumerable<promotionobject> getpromotionobjectsbyreviewcategory(this IRepository<promotionobject> repo, reviewcategoryenum category)
        {
            return repo.Find().OfType<promotionobject>().Where(p => p.promotionobjecttype.category.id == (int)category);
        }
         public  static  IEnumerable<promotionobject> getpromotionobjectsbystatus(this IRepository<promotionobject> repo, statusenum status)
        {
            return repo.Find().OfType<promotionobject>().Where(p => p.status.id == (int)status);
        }
          public  static  IEnumerable<promotionobject> getallpromotionobjects(this IRepository<promotionobject> repo)
        {
            return repo.Find().OfType<promotionobject>();
        }

          public  static  IEnumerable<promotionobject> getallpromotionobjectsbydeveloper(this IRepository<promotionobject> repo, string developer)
        {
            return repo.Find().OfType<promotionobject>().Where(p => p.detail.developer == developer);
        }
          public  static  IEnumerable<promotionobject> getallpromotionobjectsbyreviewer(this IRepository<promotionobject> repo, string reviewer)
        {

            return repo.Find().OfType<promotionobject>().Where(p => p.detail.reviewer == reviewer);

        }


        //  public static IEnumerable<promotionobjecthistory> getpromotionobjecthistbypromotionobjectid(this IRepository<promotionobject> repo, int promotionobjectid)
        //{
        //    return repo.Find().OfType<promotionobjecthistory>().Where(p => p.promotionobject.id == promotionobjectid).OrderBy(s => s.timestamp);

        //}
        //  public static IEnumerable<promotionobjecthistory> getallpromotionobjecthist(this IRepository<promotionobject> repo)
        //{
        //    return repo.Find().OfType<promotionobjecthistory>();

        //}




        ////Methods that pull stuff for  lookups

        //// IEnumerable<lu_reviewtype> GetReviewTypesources();
        //  public static IEnumerable<lu_reviewcategory> getreviewcategories(this IRepository<promotionobject> repo)
        //{
        //    return repo.Find().OfType<lu_reviewcategory>();
        //}
        //  public static IEnumerable<lu_reviewtype> getreviewtypes(this IRepository<promotionobject> repo)
        //{
        //    return repo.Find().OfType<lu_reviewtype>();
        //}
        //  public static IEnumerable<lu_deploymenttype> getdeploymenttypes(this IRepository<promotionobject> repo)
        //{
        //    return repo.Find().OfType<lu_deploymenttype>();
        //}
        //  public static IEnumerable<lu_promoter> getpromoters(this IRepository<promotionobject> repo)
        //{
        //    return repo.Find().OfType<lu_promoter>();
        //}
        //  public static IEnumerable<lu_promotionobjectfiletype> getfiletypes(this IRepository<promotionobject> repo)
        //{
        //    return repo.Find().OfType<lu_promotionobjectfiletype>() ;
        //}
        //  public static IEnumerable<lu_promotionobjecttablename> gettablenames(this IRepository<promotionobject> repo)
        //{
        //    return repo.Find().OfType<lu_promotionobjecttablename>();
        //}
        //  public static IEnumerable<lu_promotionobjecttype> getobjecttypes(this IRepository<promotionobject> repo)
        //{
        //    return repo.Find().OfType<lu_promotionobjecttype>();
        //}
        //  public static IEnumerable<lu_scripttype> getscripttypes(this IRepository<promotionobject> repo)
        //{
        //    return repo.Find().OfType<lu_scripttype>();
        //}
        //  public static IEnumerable<lu_status> getstatuses(this IRepository<promotionobject> repo)
        //{
        //    return repo.Find().OfType<lu_status>();
        //}

        //IEnumerable<Priority> GetTicketPriorities();
        //Get history/Audit table data


    }
}
