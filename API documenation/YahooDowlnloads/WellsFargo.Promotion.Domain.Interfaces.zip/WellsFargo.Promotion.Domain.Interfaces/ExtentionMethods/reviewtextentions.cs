﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WellsFargo.Promotion.Domain.Data;
using WellsFargo.Promotion.Domain.Interfaces;

namespace WellsFargo.Promotion.Domain.Extentions
{
     public  static     class reviewextentions
    {

         //  public  static  static IEnumerable<deployment> GetOrdersMatchingParams(this IRepository<deployment>, int param1, string param2)    
         //{         // Do query here and return the result    
         
         //} 


        //TO DO maybe a separaterepo
        //Methods that pull stuff for reviews
          public  static  IEnumerable<review> getreviewsbypromotionobjectid(this IRepository<review> repo,int promotionobjectid)
        {
            return repo.Find().OfType<review>().Where(p => p.promotionobject.id == promotionobjectid);
        }
          public static review getreviewbyreviewid(this IRepository<review> repo, int reviewid)
        {
            return repo.Find().OfType<review>().Where(p => p.id == reviewid).FirstOrDefault();
        }
          public static IEnumerable<review> getreviewsbyreviewtype(this IRepository<review> repo, reviewtypeenum type)
        {
            return repo.Find().OfType<review>().Where(p => p.reviewtype.id == (int)type);
        }
          public static IEnumerable<review> getreviewsbyreviewcategory(this IRepository<review> repo, reviewcategoryenum category)
        {
            return repo.Find().OfType<review>().Where(p => p.promotionobject.promotionobjecttype.category.id == (int)category);
        }
          public static IEnumerable<review> getreviewsbystatus(this IRepository<review> repo, statusenum status)
        {
            return repo.Find().OfType<review>().Where(p => p.status.id == (int)status);
        }

          public static IEnumerable<review> getreviewsbynotesstring(this IRepository<review> repo, string notes)
        {
            return repo.Find().OfType<review>().Where(p => p.detail.notes.Contains(notes));
        }

          public  static  IEnumerable<review> getallreviews(this IRepository<review> repo)
        {
            return repo.Find().OfType<review>();
        }



        //IEnumerable<Priority> GetTicketPriorities();
        //Get history/Audit table data
        //  public static IEnumerable<reviewhistory> getreviewhistbypromotionobjectid(this IRepository<review> repo, int promotionobjectid)
        //{
        //    return repo.Find().OfType<reviewhistory>().Where(p => p.review.promotionobject.id == promotionobjectid).OrderBy(s => s.timestamp);
        //}
        //  public static IEnumerable<reviewhistory> getreviewhistbyreview(this IRepository<review> repo, int reviewid)
        //{
        //    return repo.Find().OfType<reviewhistory>().Where(p => p.review.id == reviewid).OrderBy(s => s.timestamp);

        //}
        //  public  static  IEnumerable<reviewhistory> getrallreviewhist(this IRepository<review> repo)
        //{
        //    return repo.Find().OfType<reviewhistory>();

        //}
    }
}
