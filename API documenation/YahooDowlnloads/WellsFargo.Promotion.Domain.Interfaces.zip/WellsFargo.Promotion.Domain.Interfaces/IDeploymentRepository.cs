﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain.Interfaces
{

    
    
    //Extra implentations for promotion database
    public interface IDeploymentRepository<T> : IRepository<T>

    {




        IEnumerable<deployment> getdeploymentsbypromotionobjectid(int promotionobjectid);
        IEnumerable<deployment> getdeploymentsbydeploymenttype(deploymenttypeenum type);
        IEnumerable<deployment> getdeploymentsbyenviroment(enviromentenum enviroment);
        IEnumerable<deployment> getalldeployments();
        IEnumerable<deployment> getalldeploymentsbysurfid(int surfid);
        IEnumerable<deployment> getalldeploymentsbydeveloper(string developer);
        //Update methods .... are on service layer since they implement
        //Get history/Audit table data

        IEnumerable<deploymenthistory> getdeploymenthistbypromotionobjectid(int promotionobjectid);
        IEnumerable<deploymenthistory> getdeploymenthistbydeploymentid(int deploymentid);
        IEnumerable<deploymenthistory> getalldeploymenthist();
    }


   

   



   

   
}
