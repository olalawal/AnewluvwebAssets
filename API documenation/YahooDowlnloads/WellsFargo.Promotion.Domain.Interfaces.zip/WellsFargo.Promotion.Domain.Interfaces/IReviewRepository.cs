﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain.Interfaces
{

    
    
    //Extra implentations for promotion database
    public interface IReviewRepository : IRepository<review  >

    {



        //main review service implematations
        //TO DO maybe a separaterepo
        //Methods that pull stuff for reviews
        IEnumerable<review> getreviewsbypromotionobjectid(int promotionobjectid);
        review getreviewbyreviewid(int reviewid);
        IEnumerable<review> getreviewsbyreviewtype(reviewtypeenum type);
        IEnumerable<review> getreviewsbyreviewcategory(reviewcategoryenum category);
        IEnumerable<review> getreviewsbystatus(statusenum staus);
        IEnumerable<review> getreviewsbynotesstring(string notes);
        IEnumerable<review> getallreviews();
        //IEnumerable<Priority> GetTicketPriorities();
        //Get history/Audit table data
        IEnumerable<reviewhistory> getreviewhistbypromotionobjectid(int promotionobjectid);
        IEnumerable<reviewhistory> getreviewhistbyreview(int reviewid);
        IEnumerable<reviewhistory> getrallreviewhist();

        
    }


   

   



   

   
}
