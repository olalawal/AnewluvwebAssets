﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain.Interfaces
{

    
    //Extra implentations for promotion database
    public interface IPromotionRepository : IRepository<promotionobject >

    {


        IEnumerable<promotionobject> getpromotionobjectsbypromotionobjecttype(promotionobjecttypeenum type);
        promotionobject getpromotionobjectbypromotionobjectid(int promotionobjectid);
        IEnumerable<promotionobject> getpromotionobjectsbyreviewcategory(reviewcategoryenum category);
        IEnumerable<promotionobject> getpromotionobjectsbystatus(statusenum status);
        IEnumerable<promotionobject> getallpromotionobjects();
        IEnumerable<promotionobject> getallpromotionobjectsbydeveloper(string developer);
        IEnumerable<promotionobject> getallpromotionobjectsbyreviewer(string reviewer);
        
        
        
        IEnumerable<promotionobjecthistory> getpromotionobjecthistbypromotionobjectid(int promotionobjectid);
        IEnumerable<promotionobjecthistory> getallpromotionobjecthist();

      

             //Methods that pull stuff for  lookups

           // IEnumerable<lu_reviewtype> GetReviewTypesources();
            IEnumerable<lu_reviewcategory> getreviewcategories();
            IEnumerable<lu_reviewtype> getreviewtypes();
            IEnumerable<lu_deploymenttype  > getdeploymenttypes();
            IEnumerable<lu_promoter > getpromoters();
            IEnumerable<lu_promotionobjectfiletype > getfiletypes();
            IEnumerable<lu_promotionobjecttablename> gettablenames();
            IEnumerable<lu_promotionobjecttype > getobjecttypes();
            IEnumerable<lu_scripttype > getscripttypes();
            IEnumerable<lu_status> getstatuses();
           
            //IEnumerable<Priority> GetTicketPriorities();
           //Get history/Audit table data
           
          
    }


   

   




   

   
}
