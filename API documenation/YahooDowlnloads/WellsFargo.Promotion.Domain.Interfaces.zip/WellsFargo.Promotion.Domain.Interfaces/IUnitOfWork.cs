﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain.Interfaces
{
    //5-7-2013 completed changes to make this unit of work fully generic
    public interface IUnitOfWork: IDisposable 
    {
        bool EnableAuditLog { get; set; }
        bool DisableProxyCreation { set; }
        int Commit();
        IRepository<TSet> GetRepository<TSet>() where TSet : class, new(); 
        //To use less custom code manually added the 
         //IRepository<TSet> GetRepository<TSet>() where TSet : class;
        //non generic implemenation, down the line abrract this out
       // IPromotionRepository GetPromotionRepository { get; }
       // IReviewRepository GetReviewRepository { get; }
        //IDeploymentRepository GetDeploymentRepository { get; }
        //ISurfRepository GetSurfRepository { get; } 
       // IRepository<promotionobject> GetPromotionRepository { get; }
       // IRepository<review> GetReviewRepository { get; }
      //  IRepository<deployment> GetDeploymentRepository { get; }
      //  IRepository<surf> GetSurfRepository { get; }
      //  IRepository<deploymenthistory > GetDeploymentHistoryRepository { get; }
    
        DbTransaction BeginTransaction();
    }
}
