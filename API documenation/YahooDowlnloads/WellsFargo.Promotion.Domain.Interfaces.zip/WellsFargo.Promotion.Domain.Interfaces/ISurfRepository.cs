﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain.Interfaces
{

    
    
    //Extra implentations for promotion database
    public interface ISurfRepository : IRepository<surf>

    {


        //TO DO maybe a separaterepo
        //Methods that pull stuff for  deployments
        //IEnumerable<surf> GetSurfsByPromotionobjectId(int promotionobjectid);
        //IEnumerable<surf> GetDeployedSurfs();       
        //Update methods .... are on service layer since they implement

    }


   

   



   

   
}
