﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;

namespace WellsFargo.Promotion.Domain
{
    public partial class PromotionContext
    {
        //4-26-2013 olawal - added model builders for the review detail and promotion object detail
        //TO DO - determine weather we should be doing man detail ojects per rview since we have history as well
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
          //all these are moved to separate files for a cleaner look

            modelBuilder.Configurations.Add(new deploymentconfiguration());
            modelBuilder.Configurations.Add(new deploymenthistoryconfiguration());           
           
            modelBuilder.Configurations.Add(new lu_promotionobjecttypeconfiguration());  

             modelBuilder.Configurations.Add(new promotionobjectconfiguration());
             modelBuilder.Configurations.Add(new promotionobjectdetailconfiguration());  
             modelBuilder.Configurations.Add(new promotionobjecthistoryconfiguration());  
             modelBuilder.Configurations.Add(new reviewconfiguration ());
             modelBuilder.Configurations.Add(new reviewdetailconfiguration ());
             modelBuilder.Configurations.Add(new reviewhistoryconfiguration());
             modelBuilder.Configurations.Add(new lu_reviewtypeconfiguration ());  
             modelBuilder.Configurations.Add(new surfconfiguration());  
             

        }
    }
}
