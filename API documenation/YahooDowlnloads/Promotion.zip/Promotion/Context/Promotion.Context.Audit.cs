﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain
{
    //Audit table objects added 4/19/2013
    public  partial class PromotionContext 
    {

        public DbSet<deploymenthistory> deploymenthistory { get; set; }
        public DbSet<promotionobjecthistory> promotionobjecthistory { get; set; }
        public DbSet<reviewhistory> reviewhistory { get; set; }
    
    
    }

}
