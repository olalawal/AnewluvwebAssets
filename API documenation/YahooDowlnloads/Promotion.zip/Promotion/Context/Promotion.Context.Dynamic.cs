﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;

namespace WellsFargo.Promotion.Domain
{
    public  partial class PromotionContext 
    {

       // public DbSet<file > file { get; set; }
       // public DbSet<folder > folder { get; set; }
       // public DbSet<webfolder > webfolder { get; set; }
 
    }

}
