﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain
{
    //4-17-2013 olawal created   
    //4-22-2013 olawal removed script type and added status that is shared between all status based tables
    //also addded eviroment lookup 4-19-2013
    public  partial class PromotionContext 
    {

        public DbSet<lu_deploymenttype> lu_deploymenttypes { get; set; }       
        public DbSet<lu_enviroment> lu_enviroments { get; set; }
        public DbSet<lu_promoter> lu_promoters { get; set; }
        public DbSet<lu_promotionobjecttype > lu_promotionobjecttypes { get; set; }
        public DbSet<lu_promotionobjectfiletype> lu_promotionobjectfiletypes { get; set; }
        public DbSet<lu_promotionobjecttablename> lu_promotionobjecttablenames { get; set; }
        public DbSet<lu_reviewtype > lu_reviewtype { get; set; }       
        public DbSet<lu_reviewcategory > lu_reviewcategory { get; set; }
        public DbSet<lu_status> lu_statuses { get; set; }
        public DbSet<lu_scripttype> lu_scripttype { get; set; }
    }

}
