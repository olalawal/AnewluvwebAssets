﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain
{
    class reviewconfiguration : EntityTypeConfiguration<review>
    {
        internal reviewconfiguration()
        {
            //review
            //////////////////////////////////////////////
            //set pk
           this.HasKey(p => p.id);

           //rest of review relation ships       
           this.HasRequired(p => p.reviewtype).WithMany().HasForeignKey(z => z.reviewtype_id).WillCascadeOnDelete(false); ;//.WithOptional(p => p.review);
            //FK relationships'
            //review 
           this.HasRequired(p => p.promotionobjectdetail).WithMany().HasForeignKey(z => z.promotionobject_id).WillCascadeOnDelete(false); ;//.WithOptional(p => p.review);

      

            //4-29-2013 olawal - categories are associated only with promootion objects type not reviews
           //this.HasRequired(p => p.c).WithOptional(p => p.review); 
         
            //4-26-2013 olawal - flipped these around a promotion object can have many reviews
            // but each review is tied to ONE promotion object
            //4-22-2013 olawal new realation ships - one to many with promotion object
          // this.HasMany(p => p.promotionobjects).WithRequired(p => p.review);

            //4-22-2013 olawal - added hitory as a collection since one review could be audited serveal times            
           this.HasMany(p => p.history).WithRequired(p => p.review).HasForeignKey (z=>z.review_id ).WillCascadeOnDelete(false);

            //Made into 1 to 1
        //4-26-2013 olawal 1 to mnay relation ship with reviewdetail
          // this.Hap => p.details).WithRequired(p => p.review);
           //optional status relationships for deoplyment and depoyment history
           this.HasOptional(p => p.status).WithMany().HasForeignKey(z => z.status_id).WillCascadeOnDelete(false); ;//.WithOptional(p => p.review);;//.WithRequired(p => p.review);

            
        }
    }
}
