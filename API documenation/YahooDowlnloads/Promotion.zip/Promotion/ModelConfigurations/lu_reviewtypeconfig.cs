﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain
{
    class lu_reviewtypeconfiguration : EntityTypeConfiguration<lu_reviewtype >
    {
        internal lu_reviewtypeconfiguration()
        {
            this.HasRequired(p => p.category).WithMany().HasForeignKey(z => z.category_id).WillCascadeOnDelete(false); ;
            //promotion object type has some required lookups tied to that
          //  //this.HasOptional(p => p.deployment);
           // this.HasOptional(p => p.review );//.WithOptional(p => p.promotionobjecttype);
           // this.HasOptional(p => p.reviewhistory);//.WithOptional(p => p.promotionobjecttype);  //should this be optional ?
           // this.HasOptional(p => p.promotionobject);//.WithRequired(p => p.promotionobjecttype);
           // this.HasOptional(p => p.promotionobjecthistory);
        
        }
    }
}
