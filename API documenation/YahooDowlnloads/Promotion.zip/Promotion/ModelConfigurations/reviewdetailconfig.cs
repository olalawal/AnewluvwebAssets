﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain
{
    class reviewdetailconfiguration : EntityTypeConfiguration<reviewdetail >
    {
        internal reviewdetailconfiguration()
        {
            //reviewdetail
            //////////////////////////////////////////////
            //set pk
           this.HasKey(p => p.id);
           this.HasRequired(p => p.review).WithOptional(o=>o.detail).WillCascadeOnDelete(false);


         
            
        }
    }
}
