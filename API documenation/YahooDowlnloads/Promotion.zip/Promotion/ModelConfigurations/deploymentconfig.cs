﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain
{
    class deploymentconfiguration : EntityTypeConfiguration<deployment>
    {
        internal deploymentconfiguration()
        {
            //this.HasRequired(b => b.Item)
            //    .WithMany(i => i.Bids)
            //    .HasForeignKey(b => b.ItemId);

            //configure model with fluent API
            //Deployment
            //////////////////////////////////////////////
            //set pk
            this.HasKey(p=>p.id);
            //FK relationships'
            //deployment and its history
            this.HasRequired(p=>p.deploymenttype).WithMany().HasForeignKey(p=>p.deploymenttype_id).WillCascadeOnDelete(false);   
            //rest of deployment relation ships
            this.HasRequired(p => p.enviroment).WithMany().HasForeignKey(p=>p.enviroment_id).WillCascadeOnDelete(false);

            this.HasOptional(p => p.status).WithMany().HasForeignKey(p => p.status_id).WillCascadeOnDelete(false); 

            //4-22-2013 olawal - added hitory as a collection since one deployment could be audited serveal times            
            this.HasMany(p => p.history).WithRequired(p => p.deployment).HasForeignKey(z => z.deployment_id);


            this.HasRequired(p => p.promotionobjectdetail).WithMany().HasForeignKey(z => z.promotionobject_id).WillCascadeOnDelete(false); ;//.WithOptional(p => p.review);

      
            
        }
    }
}
