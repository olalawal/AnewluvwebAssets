﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain
{
     class deploymenthistoryconfiguration : EntityTypeConfiguration<deploymenthistory>
    {
    
         internal deploymenthistoryconfiguration()
        {
        //deployment history
            ///////////////////////////////////////
            //set pk
           this.HasKey(p => p.id);
           this.HasOptional(p => p.status).WithMany().HasForeignKey(z => z.status_id).WillCascadeOnDelete(false); ;//.WithRequired(p => p.deploymenthistory);
          
             //link it to its base object
           this.HasRequired(p => p.deployment).WithMany().HasForeignKey(z => z.deployment_id).WillCascadeOnDelete(false);
           
         }
    }
}
