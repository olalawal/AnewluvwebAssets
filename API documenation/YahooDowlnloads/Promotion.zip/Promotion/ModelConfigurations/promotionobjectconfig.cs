﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration;
using WellsFargo.Promotion.Domain.Data;
using System.ComponentModel.DataAnnotations.Schema;

namespace WellsFargo.Promotion.Domain
{
    class promotionobjectconfiguration : EntityTypeConfiguration<promotionobject>
    {
        internal promotionobjectconfiguration()
        {
            //promotionobject
            //////////////////////////////////////////////
            //set pk
           this.HasKey(p => p.id);
             // this.Property(p=>p.id)
            //FK relationships'
            //promotionobject and its history
           // this.HasRequired(p => p.promotionobjecttype);               

            //modelBuilder.Entity<promotionobjecthistory>().HasRequired(p => p.promotionobject).WithOptional(p => p.history);
            //rest of promotionobject relation ships       
           // this.HasRequired(p => p.promotionobjecttype).WithOptional(p => p.promotionobject);
            //optional status relationships for deoplyment and depoyment history
            this.HasOptional(p => p.status ).WithMany().HasForeignKey(p=>p.status_id);//.WithRequired(p => p.promotionobject);
            this.HasOptional(p => p.promoter).WithMany().HasForeignKey(p => p.promoter_id); ;//.WithRequired(p => p.promotionobject);                   

            //configure the many to many relationship between promotionobject and promotion object object
            //   modelBuilder.Entity<promotionobject>().HasOptional(p => p.review)
            //    .WithMany(b => b.promotionobjects);

            //4-22-2013 olawal - added hitory as a collection since one promotionobject could be audited serveal times            
          this.HasMany(p => p.history).WithRequired(p => p.promotionobject);

            //Made into 1 to 1
            //4-26-2013 olawal - added 1 to many mappin for promotionobjectdetail
          // this.HasMany(p => p.details ).WithRequired(p => p.promotionobject);
          //4-22-2013 olawal new realation ships
          this.HasRequired(p => p.surf).WithMany().HasForeignKey(p=>p.surf_id);

       
            
        }
    }
}
