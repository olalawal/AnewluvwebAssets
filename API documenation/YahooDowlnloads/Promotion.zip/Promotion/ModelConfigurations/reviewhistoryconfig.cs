﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain
{
    class reviewhistoryconfiguration : EntityTypeConfiguration<reviewhistory>
    {
        internal reviewhistoryconfiguration()
        {

            //Reviewhistory
            //////////////////////////////////////////////
            //set pk
           this.HasKey(p => p.id);
      
        

           //modelBuilder.Entity<reviewhistory>().HasMany(p => p.promotionobjects).WithRequired(p => p.);
           this.HasOptional(p => p.status).WithMany().HasForeignKey(z => z.status_id).WillCascadeOnDelete(false); ;//.WithRequired(p => p.promotionobjecthistory).Map(p => p.MapKey("status_id"));
           this.HasRequired(p => p.reviewtype ).WithMany().HasForeignKey(z => z.reviewtype_id).WillCascadeOnDelete(false); ;//.WithRequired(p => p.promotionobjecthistory);
           this.HasRequired(p => p.reviewcategory).WithMany().HasForeignKey(z => z.reviewcategory_id ).WillCascadeOnDelete(false); ;
           this.HasRequired(p => p.review ).WithMany().HasForeignKey(z => z.review_id).WillCascadeOnDelete(false); ;
            
        }
    }
}
