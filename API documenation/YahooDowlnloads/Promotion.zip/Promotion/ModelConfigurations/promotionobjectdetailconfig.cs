﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain
{
    class promotionobjectdetailconfiguration : EntityTypeConfiguration<promotionobjectdetail>
    {
        internal promotionobjectdetailconfiguration()
        {
            //review
            //////////////////////////////////////////////
            //set pk
           this.HasKey(p => p.id);
            //FK relationships'
            //review 

           //Metadata mapping made to use same KE and FK and PK
           this.HasRequired(p => p.promotionobject)
           .WithOptional(o => o.detail).WillCascadeOnDelete(false); ;  //.Map(t => t.MapKey("promotionobject_id")); 
         

           //4-26-2013 olawal - 1 promotion object many rviews
           this.HasMany(p => p.reviews).WithRequired(p => p.promotionobjectdetail ).HasForeignKey(z=>z.promotionobject_id ); ;
           //4-26-2013 olawal - 1 promotion object many rviews
           this.HasMany(p => p.deployments ).WithRequired(p => p.promotionobjectdetail).HasForeignKey(z=>z.promotionobject_id); ;   
        }
    }
}
