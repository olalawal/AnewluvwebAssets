﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain
{
    class surfconfiguration : EntityTypeConfiguration<surf>
    {
        internal surfconfiguration()
        {
            //4-22-2013 olawal added new object surf
            //surf
            //////////////////////////////////////////////
            //set pk
            this.HasKey(p => p.id);
            //1 to many relation ship with deployment i.e 1 surf can spin off several deployment items
           this.HasMany(p => p.promotionobjects).WithRequired(p => p.surf).HasForeignKey(z=>z.surf_id).WillCascadeOnDelete(false);         

            
        }
    }
}
