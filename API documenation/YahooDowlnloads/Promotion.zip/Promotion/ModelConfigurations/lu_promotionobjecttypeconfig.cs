﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain
{
    class lu_promotionobjecttypeconfiguration : EntityTypeConfiguration<lu_promotionobjecttype>
    {
        internal lu_promotionobjecttypeconfiguration()        {

            //promotion object type has some required lookups tied to that
            this.HasRequired(p => p.category).WithMany().HasForeignKey(z => z.category_id).WillCascadeOnDelete(false);
           this.HasRequired(p => p.filetype).WithMany().HasForeignKey(z => z.filetype_id).WillCascadeOnDelete(false);
           this.HasRequired(p => p.tablename).WithMany().HasForeignKey(z => z.tablename_id).WillCascadeOnDelete(false);
           this.HasOptional(p => p.scripttype).WithMany().HasForeignKey(z => z.scripttype_id).WillCascadeOnDelete(false);

           this.HasMany(p => p.promotionobjects).WithRequired(p => p.objecttype).HasForeignKey(z=>z.objecttype_id); 


        }
    }
}
