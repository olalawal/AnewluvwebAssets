﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration;
using WellsFargo.Promotion.Domain.Data;

namespace WellsFargo.Promotion.Domain
{
    class promotionobjecthistoryconfiguration : EntityTypeConfiguration<promotionobjecthistory>
    {
        internal promotionobjecthistoryconfiguration()
        {

            //promotionobjecthistory
            //////////////////////////////////////////////
            //set pk
            this.HasKey(p => p.id);
            //modelBuilder.Entity<reviewhistory>().HasMany(p => p.promotionobjects).WithRequired(p => p.);
            this.HasOptional(p => p.status).WithMany().HasForeignKey(z => z.status_id).WillCascadeOnDelete(false); ;//.WithRequired(p => p.promotionobjecthistory).Map(p => p.MapKey("status_id"));
            this.HasRequired(p => p.promotionobjecttype).WithMany().HasForeignKey(z => z.promotionobjecttype_id).WillCascadeOnDelete(false); ;
            this.HasOptional(p => p.promoter).WithMany().HasForeignKey(z => z.promoter_id).WillCascadeOnDelete(false); ;//.WithRequired(p => p.promotionobjecthistory);
            this.HasRequired(p => p.promotionobject).WithMany().HasForeignKey(z => z.promotionobject_id).WillCascadeOnDelete(false); ;
        

             
            
        }
    }
}
