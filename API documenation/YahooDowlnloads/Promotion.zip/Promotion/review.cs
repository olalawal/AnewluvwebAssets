﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WellsFargo.Promotion.Domain.Data
{
    public class review
    {
        public int id { get; set; }
        public int order { get; set; }       
        //public bool? pass { get; set; }
        //public bool? fail { get; set; }
        //public bool? na { get; set; }
        public string notes { get; set; }       
        //public DateTime? adddate { get; set; }  //this info is gleaned from history tables
        public virtual lu_reviewtype reviewtype { get; set; }  //how is review type different from review category
        public virtual lu_reviewcategory reviewcategory { get; set; }
        public virtual ICollection <promotionobject> promotionobjects { get; set; }
        public virtual lu_status status { get; set; }  //only works if pass fail na are exclusive
        public DateTime? statusdate { get; set; }  

        //forlink back to history
        public virtual ICollection<reviewhistory> history { get; set; }
    }
}
