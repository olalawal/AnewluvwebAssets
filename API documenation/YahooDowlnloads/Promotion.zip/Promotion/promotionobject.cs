﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WellsFargo.Promotion.Domain.Data
{
    public  class promotionobject
    {
        public int id { get; set; }
        public string surf { get; set; }
        public int order { get; set; }
        public string developer { get; set; }
        public string reviewer { get; set; }  //rename of reviewed by for conistency
        public int? passcount { get; set; }
        public int? failcount { get; set; }
        public bool? reviewitemsadded {get;set;}
        public string objectdetail { get; set; }
        public string reportdeploypath { get; set; }
        public DateTime? submittdate { get; set; }
        public DateTime? reviewstartdate { get; set; }
        public DateTime? reviewcompletedate { get; set; } //rename of reviewdate can roll back
        public virtual lu_status  status { get; set; }
        public virtual lu_promotionobjecttype promotionobjecttype { get; set; }
        //related to deployment 
        public virtual deployment deployment { get; set; }
        public virtual review review { get; set; }
        // public virtual reviewhistory reviewhistory { get; set; }
        public DateTime? statusupdatedate { get; set; } // this could be problematic i.e since its tied to a lookup
        //moved from review level
        public bool exceptiongranted { get; set; }
        public string exceptiongrantor { get; set; }
        public string exceptionnotes { get; set; }
        public DateTime? exceptiondate { get; set; }
       
        public int nacount { get; set; }
        
        public virtual lu_promoter promoter { get; set; }
      

        //forlink back to history
        public virtual ICollection<promotionobjecthistory> history { get; set; }
        

    }
}
