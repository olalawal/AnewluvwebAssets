﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WellsFargo.Promotion.Domain.Data
{
    public class surf
    {
        public int id { get; set; }
        public string surfid { get; set; }
        public string releasenotes { get; set; }
        public virtual ICollection<deployment> deployments{ get; set; }  //how is review type different from review category
        public DateTime? completedate { get; set; }  
    }
}
