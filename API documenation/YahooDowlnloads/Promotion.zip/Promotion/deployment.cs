﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WellsFargo.Promotion.Domain.Data
{
    public class deployment
    {
        public int id { get; set; }
        public int order { get; set; }        
        public string deploymentlocation { get; set; }  //maybe this is a part of the  promotion object
        public DateTime? deploydate { get; set; }  
        public virtual lu_deploymenttype deploymenttype { get; set; }  //how is review type different from review category
        public virtual lu_enviroment deploymentenviroment { get; set; }
        public virtual promotionobject promotionobject { get; set; }
        public virtual lu_status  status { get; set; }  //only works if pass fail na are exclusive
        public DateTime? statusdate { get; set; }
        //connection to history object 
        public virtual ICollection<deploymenthistory> history { get; set; }
        //4-22-2013 added surf info
        public virtual surf surf { get; set; }
    }
}
